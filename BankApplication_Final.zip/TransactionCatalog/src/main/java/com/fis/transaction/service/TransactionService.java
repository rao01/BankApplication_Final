package com.fis.transaction.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.transaction.Exception.NotEnoughBalance;
import com.fis.transaction.dao.TransactionDao;
import com.fis.transaction.model.Transaction;

@Service
@Transactional
public class TransactionService {
	@Autowired
	private TransactionDao dao;
	
	public List<Transaction> getTransactions(){
	
		List<Transaction> list=dao.findAll();
		if(list.isEmpty()) {
			throw new NotEnoughBalance("No Transactions found");
		}
		else return list;
	}
	
	
}
