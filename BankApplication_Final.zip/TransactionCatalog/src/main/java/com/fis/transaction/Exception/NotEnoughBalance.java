package com.fis.transaction.Exception;

public class NotEnoughBalance extends RuntimeException{


	public NotEnoughBalance(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
