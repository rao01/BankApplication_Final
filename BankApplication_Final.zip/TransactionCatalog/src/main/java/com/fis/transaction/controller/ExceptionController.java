package com.fis.transaction.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fis.transaction.Exception.NotEnoughBalance;

@ControllerAdvice
public class ExceptionController  extends ResponseEntityExceptionHandler{

	@ExceptionHandler(NotEnoughBalance.class)
	public ResponseEntity<Object> handler(NotEnoughBalance e){
		
		return new ResponseEntity<Object>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
}
