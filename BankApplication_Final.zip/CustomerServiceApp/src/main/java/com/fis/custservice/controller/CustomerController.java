package com.fis.custservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.custservice.model.Customer;
import com.fis.custservice.model.CustomerDTO;
import com.fis.custservice.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService service;
	
	@GetMapping("/customers")
	public ResponseEntity<CustomerDTO> getCustomers(){
		CustomerDTO dto=new CustomerDTO();
		dto.setList(service.getAll());
		return new ResponseEntity<CustomerDTO>(dto,HttpStatus.OK);
	}
	
	@PostMapping("/addCustomer")
	public ResponseEntity<Object> addCustomer(@RequestBody Customer cust){
		if(service.addCustomer(cust)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	//cart-customer; item-cust
	@PostMapping("/updateCustomer")
	public ResponseEntity<Object> updateCustomer(@RequestBody Customer cust){
		if(service.updateCustomer(cust)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	
	@DeleteMapping("/deleteCustomer/{custId}")
	public ResponseEntity<Object> deleteCustomer(@PathVariable("custId") int custId){
		service.deleteCustomer(custId);
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/deleteAll")
	public ResponseEntity<Object> deleteAll(){
		service.deleteAll();
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
}
