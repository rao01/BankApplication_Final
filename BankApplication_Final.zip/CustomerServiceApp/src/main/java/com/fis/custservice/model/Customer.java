package com.fis.custservice.model;

import java.util.Date;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import com.fasterxml.jackson.annotation.JsonFormat;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "customers")
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	//@Size(min = 4, max = 15, message = "customer name length must be between 6-15")
	//@NotBlank(message = "customer name cannot be null or whitespace")
	private String custName;
	//@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date custDob;
	//@Pattern(regexp = "^[0-9]{10}", message ="Mobile number must be 10 digits")
	private long mobile;
	private String custMail;  
	@NotBlank(message = "customer address cannot be null or whitespace")
	private String custAddress;
	
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Date getCustDob() {
		return custDob;
	}
	public void setCustDob(Date custDob) {
		this.custDob = custDob;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getCustMail() {
		return custMail;
	}
	public void setCustMail(String custMail) {
		this.custMail = custMail;
	}
	
	
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	
	public Customer(int custId, String custName, Date custDob, long mobile, String custMail, String custAddress) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custDob = custDob;
		this.mobile = mobile;
		this.custMail = custMail;
		this.custAddress = custAddress;
	}
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public Customer(int custId2, String custName2, String string, int mobile2, String custMail2, String custAddress2) {
		// TODO Auto-generated constructor stub
	}
	
	
}