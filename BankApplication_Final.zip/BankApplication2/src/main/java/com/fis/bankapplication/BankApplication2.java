package com.fis.bankapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankApplication2 {

	public static void main(String[] args) {
		SpringApplication.run(BankApplication2.class, args);
	}

}
