package com.fis.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class AccountCatalogApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountCatalogApplication.class, args);
	}

}
