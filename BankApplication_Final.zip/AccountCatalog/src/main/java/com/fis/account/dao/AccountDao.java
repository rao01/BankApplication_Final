package com.fis.account.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.account.model.Account;

public interface AccountDao extends JpaRepository<Account, Long> {

//	public List<Product> getproducts();
}
