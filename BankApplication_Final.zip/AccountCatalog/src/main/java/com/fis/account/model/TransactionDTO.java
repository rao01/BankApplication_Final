package com.fis.account.model;

import java.util.List;

public class TransactionDTO {

	private List<Transaction> list;

	public List<Transaction> getList() {
		return list;
	}

	public void setList(List<Transaction> list) {
		this.list = list;
	}

	
	
	@Override
	public String toString() {
		return "transactionDTO [list=" + list + "]";
	}

	
	
	
}
