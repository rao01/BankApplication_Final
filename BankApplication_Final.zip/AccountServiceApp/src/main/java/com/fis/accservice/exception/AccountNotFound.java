package com.fis.accservice.exception;

public class AccountNotFound extends Exception {

	public AccountNotFound(String message) {
		super(message);
	}

}
