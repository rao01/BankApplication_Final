package com.fis.accservice;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.PersistenceException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.validation.annotation.Validated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fis.accservice.model.Account;
import com.fis.accservice.service.AccountService;
import com.fis.accservice.dao.AccountDao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
//import com.fis.custservice.model.Account;
//import com.fis.custservice.service.AccountService;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

//import com.fis.bankapp.model.Transaction;
//import com.fis.bankapp.exception.AccountNotFound;
import com.fis.accservice.exception.AccountNotFound;
import com.fis.accservice.exception.NoRecordsException;
//import com.fis.bankapp.service.TransactionService;

@SpringBootTest
class BankAppApplication {
	
	@MockBean
	AccountDao dao;
	
	@Autowired
	AccountService service;

	private MockMvc mockMvc;

//	@Test
//	public void testAddCustomer() {
//		Customer customer = new Customer(1,"deepak",new Date(), 456785677l, "deepak@gmail.com", "fcgvhb");
//		
//		String msg = service.addCustomer(customer);
//		assertEquals("Customer added successfully",msg);
//	}
	
	@Test
	public void testAddAccount() {
		Account account = new Account(1,1234,"savings","xcvh", "ghjn", 567);
		Mockito.when(dao.save(account)).thenReturn(account);
		boolean res = service.addAccount(account);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	public void testUpdateAccount() {
		Account account = new Account(1,1234,"savings","xcvh", "ghjn", 567);
		Mockito.when(dao.save(account)).thenReturn(account);
		boolean res = service.updateAccount(account);
		System.out.println(res);
		assertTrue(res);
	}
	
//	@Test
//	public void testDeleteCustomer() {
//		Customer customer = new Customer(1,"deepak",new Date(), 456785677l, "deepak@gmail.com", "fcgvhb");
//		Mockito.when(dao.save(customer)).thenReturn(customer);
//		List<Customer> custList=new ArrayList<Customer>();
//
//		Mockito.when(dao.findAll()).thenReturn(custList);
//		Mockito.verify(dao, times(1)).deleteAll();
//		
//		int custId;
//		boolean res = service.deleteAll();
//		System.out.println(res);
//		assertTrue(res);
//	}
	
	
	
	@Test
	@DisplayName("View Account By Id- Successful")
	public void getAll() throws NoRecordsException{
 
		Account account = new Account(1,1234,"savings","xcvh", "ghjn", 567);
		Mockito.when(dao.save(account)).thenReturn(account);
		List<Account> accList=new ArrayList<Account>();
		List<Account> reaccList= new ArrayList<Account>();
        try {
        Mockito.when(dao.findAll()).thenReturn(accList);
       	reaccList = service.getAll();
       	assertEquals(accList, reaccList);
        }
        catch (NoRecordsException e){
        	e.getMessage();
        	
        }
       
	}
	
	
	
	
//	@Test
//	public void testUpdateCustomer() throws CustomerNotFound {
//		Customer customer = new Customer(1,"deepak",new Date(), 456786798l, "deepak@gmail.com", "fcgvhb");
//	
//		String msg = service.updateCustomer(customer);
//		assertEquals("Customer updated successfully",msg);
//	}
//	
//	@Test
//	public void testDeleteCustomer() throws CustomerNotFound {
//		Customer customer = new Customer(1,"deepak",new Date(), 456787799l, "deepak@gmail.com", "fcgvhb");
//		
//		service.addCustomer(customer);
//		String msg = service.deleteCustomer(1);
//		assertEquals("Customer deleted successfully",msg);
//	}
//	
//	
//	
//	
//	@Test
//	public void testAddAccount() {
//		Account account = new Account(1,"savings","xcvh", "ghjn", 567);
//
//		String msg = service2.addAccount(account);
//		assertEquals("Account created successfully",msg);
//	}
//	
//	
//	@Test
//	public void testUpdateAccount() {
//		Account account = new Account(1,"savings","xcvh", "ghjn", 567);
//		String msg = service2.updateAccount(account);
//		assertEquals("Account updated successfully",msg);
//	}
//	
//	
//	@Test
//	public void testDeleteAccount() throws AccountNotFound {
//		Account account = new Account(1,"savings","xcvh", "ghjn", 567);
//		
//		service2.addAccount(account);
//		String msg = service2.deleteAccount(1);
//		assertEquals("Account deleted successfully",msg);
//	}
//	
//	
//	
//	@Test
//	public void testAddTransaction() {
//		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
//		
//		String msg = service3.addTransaction(transaction);
//		assertEquals("Transaction added",msg);
//	}

}
