package com.fis.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.customer.model.Customer;
import com.fis.customer.model.CustomerDTO;
import com.fis.customer.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService service;
	
	@GetMapping("/customers")
	public ResponseEntity<CustomerDTO> getCustomers(){
		List<Customer> list= service.getCustomers();
		CustomerDTO dto=new CustomerDTO();
		dto.setList(list);
		return new ResponseEntity<CustomerDTO>(dto,HttpStatus.OK);
		
	}
}
