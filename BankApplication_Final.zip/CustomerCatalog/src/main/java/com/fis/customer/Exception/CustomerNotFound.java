package com.fis.customer.Exception;

public class CustomerNotFound extends RuntimeException{


	public CustomerNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
